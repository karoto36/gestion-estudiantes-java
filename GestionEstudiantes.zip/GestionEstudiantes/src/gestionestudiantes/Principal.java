package gestionestudiantes;

public class Principal {
    public static void main(String[] args) {
        Estudiante est1 = new Estudiante("Ana", 12345, 20, 85.5);
        Estudiante est2 = new Estudiante("Luis", 12346, 22, 65.0);

        est1.mostrarInformacion();
        System.out.println("¿Aprobado?: " + est1.esAprobado());

        System.out.println("---------------------------");

        est2.mostrarInformacion();
        System.out.println("¿Aprobado?: " + est2.esAprobado());
    }
}
